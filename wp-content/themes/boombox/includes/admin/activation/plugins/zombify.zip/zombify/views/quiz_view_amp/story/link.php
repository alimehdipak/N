<div class="zfLink">
    <h3 class="zfTitle"><?php echo $story_data["link_headline"]; ?></h3>
    <?php echo $story_data["link_description"]; ?>
    <strong><?php esc_html_e("Source", "zombify"); ?> </strong><a href="<?php echo $story_data["link_link"]; ?>" target="_blank" rel="noopener"><?php echo $story_data["link_link"]; ?></a>
</div>