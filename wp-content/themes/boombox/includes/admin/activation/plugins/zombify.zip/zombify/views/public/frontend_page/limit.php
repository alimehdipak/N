<h3><?php _e("Sorry, but you have just reached the daily limit for submitting new content.", "zombify") ?></h3>
<p><?php _e("You are welcome to add more tomorrow.", "zombify") ?></p>